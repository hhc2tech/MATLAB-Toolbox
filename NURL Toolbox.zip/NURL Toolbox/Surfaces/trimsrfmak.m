function tsrf=trimsrfmak(srf, crv, pcrv)

tsrf.form='T-NURLS';
tsrf.surface=srf;
tsrf.curve=crv;
tsrf.paras=pcrv;